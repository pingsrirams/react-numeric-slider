import "./App.css";
import Carousel from "./components/carousel/carousel";

function App() {
  return (
    <div className="App">
      <div className="container">
        <Carousel
          slides={[
            "https://media.santabanta.com/medium1/nature/aquatic/aquatic-203a.jpg",
            "https://media.santabanta.com/medium1/nature/aquatic/aquatic-202a.jpg",
            "https://media.santabanta.com/medium1/nature/birds/birds-414a.jpg",
            "https://media.santabanta.com/medium1/nature/butterfly/butterfly-70a.jpg",
          ]}
        />
      </div>
    </div>
  );
}

export default App;
